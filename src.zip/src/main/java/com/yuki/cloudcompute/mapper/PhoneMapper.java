package com.yuki.cloudcompute.mapper;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yuki.cloudcompute.entity.Phone;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface PhoneMapper extends BaseMapper<Phone> {

    List<Phone> getAll();

    List<JSONObject> callingProblemOne();

    List<JSONObject> calledProblemOne();

    List<JSONObject> callingProblemTwo();

    List<JSONObject> calledProblemTwo();

    List<JSONObject> beforeProblemThree();

    List<JSONObject> callingProblemThree();

}




