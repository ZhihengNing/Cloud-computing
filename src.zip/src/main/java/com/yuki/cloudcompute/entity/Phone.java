package com.yuki.cloudcompute.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.util.Date;

import lombok.Builder;
import lombok.Data;

/**
 * 
 * @TableName phone
 */
@TableName(value ="phone")
@Data
@Builder
public class Phone implements Serializable {
    /**
     * 日期
     */
    private Date dayId;

    /**
     * 主叫号码
     */
    private String callingNbr;

    /**
     * 被叫号码
     */
    private String calledNbr;

    /**
     * 主叫号码运营商
     */
    private String callingOptr;

    /**
     * 被叫号码运营商
     */
    private String calledOptr;

    /**
     * 主叫号码归属地
     */
    private String callingCity;

    /**
     * 被叫号码归属地
     */
    private String calledCity;

    /**
     * 主叫号码漫游城市
     */
    private String calllingRoamCity;

    /**
     * 被叫号码漫游城市
     */
    private String calledRoamCity;

    /**
     * 通话开始时间
     */
    private Date startTime;

    /**
     * 通话结束时间
     */
    private Date endTime;

    /**
     * 通话时长
     */
    private Integer rawDur;

    /**
     * 通话类型
     */
    private String callType;

    /**
     * 主叫蜂窝号码
     */
    private String callingCell;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}