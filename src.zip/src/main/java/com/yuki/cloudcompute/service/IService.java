package com.yuki.cloudcompute.service;

import java.io.IOException;

public interface IService {

    void test();

    void problemOne() throws IOException;

    void problemTwo() throws IOException;

    void problemThree() throws IOException;
}
