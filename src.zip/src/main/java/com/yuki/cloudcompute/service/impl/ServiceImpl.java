package com.yuki.cloudcompute.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.yuki.cloudcompute.mapper.PhoneMapper;
import com.yuki.cloudcompute.service.IService;
import com.yuki.cloudcompute.utils.TimeUtil;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

@Service
public class ServiceImpl implements IService {

    @Resource
    private PhoneMapper mapper;

    @Override
    public void test() {
        System.out.println(mapper.selectList(null));
    }

    public void problemOne() throws IOException {
        List<JSONObject> phones = mapper.callingProblemOne();
        BufferedWriter writer = new BufferedWriter(new FileWriter("src/main/resources/result/AResult.txt"));
        BufferedWriter writer1 = new BufferedWriter(new FileWriter("src/main/resources/temp/oneEd.txt"));
        for (JSONObject item : phones) {
            writer.write(item.getString("calling_nbr") + "\t"
                    + item.getString("times") +
                    "     "
                    + item.getString("times2"));
            writer.newLine();
        }
        List<JSONObject> phones1 = mapper.calledProblemOne();
        for (JSONObject item : phones1) {
            writer1.write(item.getString("called_nbr") + "\t"
                    + item.getString("times")
                    + "     " +
                    item.getString("times2"));
            writer1.newLine();
        }
        writer.close();
        writer1.close();
    }

    public void problemTwo() throws IOException {
        List<JSONObject> phones = mapper.callingProblemTwo();
        //主叫号码的存储
        BufferedWriter writer = new BufferedWriter(new FileWriter("src/main/resources/temp/two.txt"));
        //被叫号码的存储
        BufferedWriter writer1 = new BufferedWriter(new FileWriter("src/main/resources/temp/twoEd.txt"));
        for (JSONObject item : phones) {
            writer.write(item.getString("calling_optr") + "\t" +
                    item.getString("call_type") + "\t" +
                    item.getString("times"));
            writer.newLine();
        }
        List<JSONObject> phones1 = mapper.calledProblemTwo();
        for (JSONObject item : phones1) {
            writer1.write(item.getString("called_optr") + "\t" +
                    item.getString("call_type") + "\t" +
                    item.getString("times"));
            writer1.newLine();
        }
        writer.close();
        writer.close();
    }

    @Override
    public void problemThree() throws IOException {
        List<JSONObject> phones = mapper.beforeProblemThree();
        BufferedWriter writer = new BufferedWriter(new FileWriter("src/main/resources/temp/TempResult2.txt"));
        for (JSONObject item : phones) {
            writer.write(item.getString("calling_nbr") + "\t" +
                    item.getString("rawdur"));
            writer.newLine();
        }
        List<JSONObject> list = mapper.callingProblemThree();
        TimeUtil.operation(list);
        writer.close();
    }


}
