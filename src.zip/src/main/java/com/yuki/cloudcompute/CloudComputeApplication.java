package com.yuki.cloudcompute;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.yuki.cloudcompute.mapper")
public class CloudComputeApplication {

    public static void main(String[] args) {
        SpringApplication.run(CloudComputeApplication.class, args);
    }

}
