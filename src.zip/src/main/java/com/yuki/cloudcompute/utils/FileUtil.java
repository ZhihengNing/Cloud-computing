package com.yuki.cloudcompute.utils;

import com.yuki.cloudcompute.entity.Phone;
import org.junit.jupiter.api.Test;

import java.io.*;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class FileUtil {
    private static final int DATASET_SIZE=14;
    /**
     * 清洗数据
     */
    public static void readFile() throws IOException, ParseException {
        String iPath = "src/main/resources/data/data.txt";
        String oPath = "src/main/resources/data/newData.txt";
        BufferedReader reader = new BufferedReader(new FileReader(iPath));
        BufferedWriter writer = new BufferedWriter(new FileWriter(oPath));
        String buffer;
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat format1 = new SimpleDateFormat("yyyyMMddHH:mm:ss");
        while ((buffer = reader.readLine()) != null) {
            String[] split = buffer.split("\\s+");
            Phone build = Phone.builder().dayId(format.parse(split[0]))
                    .callingNbr(split[1])
                    .calledNbr(split[2])
                    .callingOptr(split[3])
                    .calledOptr(split[4])
                    .callingCity(split[5])
                    .calledCity(split[6])
                    .calllingRoamCity(split[7])
                    .calledRoamCity(split[8])
                    .startTime(format1.parse(split[0] + split[9]))
                    .endTime(format1.parse(split[0] + split[10]))
                    .rawDur(Integer.valueOf(split[11]))
                    .callType(split[12])
                    .callingCell(split[13]).build();
            Calendar newTime = Calendar.getInstance();
            newTime.setTime(build.getStartTime());
            int i = newTime.get(Calendar.MONTH) + 1;

            String date = newTime.get(Calendar.DATE) > 9 ? String.valueOf(newTime.get(Calendar.DATE))
                    : "0" + newTime.get(Calendar.DATE);

            String begin = newTime.get(Calendar.YEAR) + "-" + "0" + i + "-" + date
                    + " " + newTime.get(Calendar.HOUR_OF_DAY) + ":" + newTime.get(Calendar.MINUTE) + ":" + newTime.get(Calendar.SECOND);

            newTime.add(Calendar.SECOND, build.getRawDur());

            String date1 = newTime.get(Calendar.DATE) > 9 ? String.valueOf(newTime.get(Calendar.DATE))
                    : "0" + newTime.get(Calendar.DATE);

            int k = newTime.get(Calendar.MONTH) + 1;
            String end = newTime.get(Calendar.YEAR) + "-" + "0" + k + "-" + date1
                    + " " + newTime.get(Calendar.HOUR_OF_DAY) + ":" + newTime.get(Calendar.MINUTE) + ":" + newTime.get(Calendar.SECOND);

            //String s = newTime.get(Calendar.HOUR) + ":" + newTime.get(Calendar.MINUTE) + ":" + newTime.get(Calendar.SECOND);
            build.setEndTime(newTime.getTime());
            StringBuilder builder1 = new StringBuilder(split[0]);
            String builder = builder1.insert(6, "-").insert(4, "-") + "," +
                    build.getCallingNbr() + "," +
                    build.getCalledNbr() + "," +
                    build.getCallingOptr() + "," +
                    build.getCalledOptr() + "," +
                    build.getCallingCity() + "," +
                    build.getCalledCity() + "," +
                    build.getCalllingRoamCity() + "," +
                    build.getCalledRoamCity() + "," +
                    begin + "," +
                    end + "," +
                    build.getRawDur() + "," +
                    build.getCallType() + "," +
                    build.getCallingCell();
            writer.write(builder);
            writer.newLine();
            writer.flush();
        }
    }

    /**
     * 查看有多少重复的数据，对数据表进行分析
     */
    @Test
    public void check() throws IOException {
        String iPath = "src/main/resources/data/data.txt";
        BufferedReader reader = new BufferedReader(new FileReader(iPath));
        String temp;
        List<Set<String>> sets = new ArrayList<>();
        for (int i = 0; i < DATASET_SIZE; i++) {
            sets.add(new HashSet<>());
        }
        Map<String, Integer> map = new HashMap<>();
        while ((temp = reader.readLine()) != null) {
            String[] split = temp.split("\\s+");
            for (int k = 0; k < 14; k++) {
                sets.get(k).add(split[k]);
            }
        }
        System.out.println("dayId:"+" "+sets.get(0).size());
        System.out.println("callingNbr:"+" "+sets.get(1).size());
        System.out.println("calledNbr:"+" "+sets.get(2).size());
        System.out.println("callingOptr:"+" "+sets.get(3).size());
        System.out.println("calledOptr:"+" "+sets.get(4).size());
        System.out.println("callingCity:"+" "+sets.get(5).size());
        System.out.println("calledCity:"+" "+sets.get(6).size());
        System.out.println("callingRoamCity:"+" "+sets.get(7).size());
        System.out.println("calledRoamCity:"+" "+sets.get(8).size());
        System.out.println("startTime:"+" "+sets.get(9).size());
        System.out.println("endTime:"+" "+sets.get(10).size());
        System.out.println("rawDur:"+" "+sets.get(11).size());
        System.out.println("callType:"+" "+sets.get(12).size());
        System.out.println("callingCell:"+" "+sets.get(13).size());

        sets.get(1).retainAll(sets.get(2));
        System.out.println("主叫号码与被叫号码的交集数量为:"+" "+sets.get(1).size());
        reader.close();

    }

    /**
     * 解析文件
     */
    @Test
    public  void readThreeResult() throws IOException {
        String path="src/main/resources/temp/TempResult.txt";
        String outPutPath="src/main/resources/result/CReuslt.txt";
        BufferedReader reader=new BufferedReader(new FileReader(path));
        BufferedWriter writer=new BufferedWriter(new FileWriter(outPutPath));
        String temp;
        DecimalFormat df=new DecimalFormat("0.00");
        while ((temp=reader.readLine())!=null){
            String[] split = temp.split("\\[");
            String[] result = split[1].replace("]", "").split(",");
            int sum = Arrays.stream(result).mapToInt(s->Integer.parseInt(s.trim())).sum();
            StringBuilder build = new StringBuilder();
            for (String s : result) {
                if(sum!=0) {
                    build.append(df.format(Integer.parseInt(s.trim()) / (sum*1.0)*100)).append("% ");
                }else{
                    build.append(0.00).append("% ");
                }
            }
            writer.write(split[0]+"\t\t"+build);
            writer.newLine();
        }
        writer.close();
    }


}
