package com.yuki.cloudcompute.utils;

import com.alibaba.fastjson.JSONObject;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class TimeUtil {

    private static Map<String, List<Integer>> nbrMap = new HashMap<>();

    public static void timeDivision(String callingNbr, int begin, int end) {
        int beginNum = begin / (3 * 3600);

        int endNum = end / (3 * 3600);
        List<Integer> list = nbrMap.get(callingNbr);
        if (endNum == beginNum) {
            list.set(beginNum, list.get(beginNum) + end - begin);
        } else if (endNum < beginNum) {
            for (int i = 0; i < endNum; i++) {
                list.set(i, list.get(i) + 3 * 3600);
            }
            for (int i = beginNum + 1; i < 8; i++) {
                list.set(i, list.get(i) + 3 * 3600);
            }
            list.set(beginNum, list.get(beginNum) + (beginNum + 1) * 3 * 3600 - begin);

            list.set(endNum, list.get(endNum) + end - endNum * 3 * 3600);
        } else {
            for (int i = beginNum + 1; i < endNum; i++) {
                list.set(i, list.get(i) + 3 * 3600);
            }

            list.set(beginNum, list.get(beginNum) + (beginNum + 1) * 3 * 3600 - begin);

            list.set(endNum, list.get(endNum) + end - endNum * 3 * 3600);
        }

    }

    private static int getSeconds(Date date) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Calendar instance = Calendar.getInstance();
        instance.setTime(date);
        int k = instance.get(Calendar.MONTH) + 1;
        String need = instance.get(Calendar.YEAR) + "-" + k + "-" +
                instance.get(Calendar.DATE);
        try {
            return (int) (date.getTime() - format.parse(need).getTime()) / 1000;
        } catch (ParseException e) {
            return 0;
        }
    }

    public static void operation(List<JSONObject> list) throws IOException {
        init();
        for (JSONObject item : list) {
            Date start_time = item.getDate("start_time");
            Date end_time = item.getDate("end_time");
            timeDivision(item.getString("calling_nbr"),
                    getSeconds(start_time), getSeconds(end_time));
        }
        end();
    }

    public static void operation1(Date startTime,Date endTime,String callingNbr) throws IOException {
        init();
        timeDivision(callingNbr, getSeconds(startTime), getSeconds(endTime));
        end();
    }


    public static void init() throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader("src/main/resources/temp/TempResult2.txt"));
        String temp;
        while ((temp = reader.readLine()) != null) {
            String[] split = temp.split("\\s+");
            List<Integer> arr = Arrays.asList(0, 0, 0, 0, 0, 0, 0, 0);
            nbrMap.put(split[0], arr);
        }
    }

    public static void end() throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter("src/main/resources/temp/TempResult.txt"));
        for (Map.Entry<String, List<Integer>> entry : nbrMap.entrySet()) {
            writer.write(entry.getKey() + entry.getValue());
            writer.newLine();
        }
        writer.close();
    }


//    public static void main(String[] args) throws ParseException {
//        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//        Date parse = dateFormat.parse("2012-02-02 6:00:57");
//        System.out.println(getSeconds(parse));
//    }

}
