package com.yuki.cloudcompute.controller;

import com.yuki.cloudcompute.service.IService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.io.IOException;

@RestController
@RequestMapping("/phone")
public class Controller {
    @Resource
    private IService service;

    @RequestMapping(value = "/demo",method = RequestMethod.GET)
    public void test(){
        service.test();
    }

    @RequestMapping(value = "/one", method = RequestMethod.GET)
    public String problemOne() {
        try {
            service.problemOne();
        } catch (IOException e) {
            return "failure";
        }
        return "success";
    }

    @RequestMapping(value = "/two", method = RequestMethod.GET)
    public String problemTwo() {
        try {
            service.problemTwo();
        } catch (IOException e) {
            return "failure";
        }
        return "success";
    }

    @RequestMapping(value = "/three", method = RequestMethod.GET)
    public String problemThree() {
        try {
            service.problemThree();
        } catch (IOException e) {
            return "failure";
        }
        return "success";
    }

}
