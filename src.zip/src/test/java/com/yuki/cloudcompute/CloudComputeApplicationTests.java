package com.yuki.cloudcompute;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudComputeApplicationTests {

    @Test
    void contextLoads() {
    }

}
